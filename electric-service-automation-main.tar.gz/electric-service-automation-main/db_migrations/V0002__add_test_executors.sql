-- Add more test executors
INSERT INTO executors (name, phone, experience_years, rating) VALUES
('Дмитрий Сидоров', '+79991234568', 8, 4.8),
('Максим Петров', '+79991234569', 15, 5.0),
('Сергей Кузнецов', '+79991234570', 5, 4.7);
